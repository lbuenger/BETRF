#include <iostream>
#include <fstream>
#include <sstream>
#include <random>
#include <cmath>
#include <cassert>
#include <tuple>
#include <chrono>
#include <algorithm>

#include "OptimizedPathIfTree_128000.h"

void readCSV(float * XTest, unsigned int * YTest) {
	std::string line;
	std::ifstream file("test.csv");
	unsigned int xCnt = 0;
	unsigned int yCnt = 0;
	unsigned int lineCnt = 0;

	if (file.is_open()) {
		while ( std::getline(file,line)) {
			if ( line.size() > 0) {
				std::stringstream ss(line);
				std::string entry;
				unsigned int first = true;

				while( std::getline(ss, entry,',') ) {
					if (entry.size() > 0) {
						if (first) {
							YTest[yCnt++] = (unsigned int) atoi(entry.c_str());
							first = false;
						} else {
							//XTest[xCnt++] = (float) atoi(entry.c_str());
							XTest[xCnt++] = (float) atof(entry.c_str());
						}
					}
				}
				lineCnt++;
				if( lineCnt > 1625 ) {
					break;
				}
			}
		}
		file.close();
	}

}

int main(int argc, char const *argv[]) {

	//std :: cout << "=== NEW PERFORMANCE TEST ===" << std :: endl;
	//std :: cout << "Testing dimension:	" << 11 << std :: endl;
	//std :: cout << "Feature type:	 "<< "float" << std :: endl;
	//std :: cout << "Testing instances:	" << 1625 << std :: endl << std :: endl;
	//std :: cout << "Loading testing data..." << std :: endl;

	float * XTest = new float[11*1625];
 	unsigned int * YTest = new unsigned int[1625];
	readCSV(XTest,YTest);

	std::vector<float> accuracies;
	std::vector<float> avgd_accuracies;
	std::vector<float> max_accuracies;
	std::vector<float> min_accuracies;

	std::vector<float> runtimes;
	unsigned int pred;

	// bit error rates we test
	std::vector<float> bers = {0.000000001, 0.0000001, 0.000001, 0.00001, 0.0001, 0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.007, 0.008, 0.009, 0.01, 0.02, 0.03, 0.04, 0.05, 0.1};
	// number of repetitions for each bit error rate
	unsigned int reps_per_ber = 10;
	for (float ber : bers){
		for (unsigned int i = 0; i < reps_per_ber; ++i) {
			float acc = 0;
			auto start = std::chrono::high_resolution_clock::now();
			for (unsigned int j = 0; j < 1625; ++j) {
				// calls the decision tree
				pred = OptimizedPathIfTree_128000_predict(&XTest[11*j], ber);
				// nr of correct predictions
				acc += (pred == YTest[j]);
				//acc += pred;
			}
			auto end = std::chrono::high_resolution_clock::now();
			std::chrono::nanoseconds duration = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start);

			// divide by 1625 since that is the number of samples here
			// in the c++-code generator, find the variable for number of samples
			runtimes.push_back((float) (duration.count() / 1625.0f));
			// accuracy here is correct_predictions/nrSamples
			accuracies.push_back(acc/1625.0f);
		}

		// average over repetitions
		auto n = accuracies.size();
		float average = 0.0f;
		if (n != 0) {
			average = accumulate(accuracies.begin(), accuracies.end(), 0.0) / n;
		}
		avgd_accuracies.push_back(average);

		// calculate max and min values
		max_accuracies.push_back(*max_element(accuracies.begin(),accuracies.end()));
		min_accuracies.push_back(*min_element(accuracies.begin(),accuracies.end()));

		accuracies.clear();
		//max_accuracies.clear();
		//min_accuracies.clear();
	}

	std :: cout << "accuracy\nmean max min" << std :: endl;
	for (unsigned int k = 0; k < avgd_accuracies.size(); k++){
		std :: cout << "BER " <<  bers[k] << ": " <<  100*(avgd_accuracies[k])
			<< " " << 100*(max_accuracies[k]) << " " << 100*(min_accuracies[k])
		 	<< std :: endl;
	}
	//std :: cout << "Runtime per element (ms): " << avg << " ( " << var / (cnt - 1) << " )" <<std :: endl;
	//std :: cout << avg << "," << var / (cnt - 1) << "," << min << "," << max << std :: endl;

	delete[] XTest;
 	delete[] YTest;

  // we need to write out the accuracy over bit error rate into a jsonl file

	return 1;
}
